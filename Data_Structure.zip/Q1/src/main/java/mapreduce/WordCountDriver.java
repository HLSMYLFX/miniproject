package mapreduce;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.IOException;

public class WordCountDriver {
    public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
        // Get the current default configuration
        Configuration conf = new Configuration();
        // Get job object
        Job job = Job.getInstance(conf);
        // Specify the entry class of the current program
        job.setJarByClass(WordCountDriver.class);

        //Mapper class
        job.setMapperClass(WordCountMapper.class);
        // Reducer class
        job.setReducerClass(WordCountReducer.class);

        /*
        Mapper output
         */
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(LongWritable.class);

        /*
        Reducer output
         */
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(LongWritable.class);

        /**
         * Set the path, including the input file and output path
         *The path is a local path, if you want to run on the server, you need to change to the server path
         */
        Path inputPath = new Path("file:///E:\\test\\minipro\\access_log");
        Path outputPath = new Path("file:///E:\\test\\minipro\\outputq1");

        FileInputFormat.setInputPaths(job, inputPath);
        FileSystem fileSystem = FileSystem.get(conf);
        // The folder of the output path cannot exist. If it exists, it will be deleted.
        if(fileSystem.exists(outputPath)){
            fileSystem.delete(outputPath, true);
            System.out.println("The path exists but has been deleted");
        }
        FileOutputFormat.setOutputPath(job, outputPath);

        job.waitForCompletion(true);
    }
}