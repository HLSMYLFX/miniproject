package mapreduce;
//dont run this, just for test!!
public class test {
    public static void main(String[] args){
        ParserLogs parserLog = new ParserLogs();
        String[] parser =
                parserLog.parser("27.19.74.143 - - [30/May/2018:17:38:20 +0800] \"GET /static/image/common/faq.gif HTTP/1.1\" 200 1127");
        for (String s : parser){
            System.out.println(s);
        }
    }
}
