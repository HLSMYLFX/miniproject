package mapreduce;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class WordCountMapper extends Mapper<LongWritable, Text, Text, LongWritable> {
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        // First get a row of data
        String lines = value.toString();
        //Data cleaning of log data
        ParserLogs parserLog = new ParserLogs();
        String[] parser = parserLog.parser(lines);
        //map
        for (String str : parser) {
            context.write(new Text(str), new LongWritable(1));
        }
    }
}