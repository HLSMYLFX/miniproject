package mapreduce;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;


public class ParserLogs {
    public static final SimpleDateFormat FORMAT  = new SimpleDateFormat("dd/MMM/yyyy:HH:mm:ss", Locale.ENGLISH);
    public static final SimpleDateFormat FORMATDATE = new SimpleDateFormat("yyyyMMddHHmmss");
    //ip
    public String parserIp(String line){
        String[] ips;
        String[] i = line.split("- -");
        //System.out.println(i[0].length());
        if(i[0].length()>15){
            ips = i[0].split("- associates");
        }
        else {
            ips = i;
        }
        String ip = ips[0].trim();
        //System.out.println(ip);
        return ip;
    }
    //time
    public String parserTime(String line){
        int first = line.indexOf("[");
        int last = line.indexOf("]");
        String time = line.substring(first+1,last);
        Date parse = null;
        try {
            parse = FORMAT.parse(time);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return FORMATDATE.format(parse);
    }

    //url
    public String parserUrl(String line){
        int indexOf = line.indexOf("\"");
        int lastIndexOf = line.lastIndexOf("\"");
        return line.substring(indexOf + 1,lastIndexOf);
    }

    //status
    public String parserStatus(String line){
        String trim = line.substring(line.lastIndexOf("\"")+1).trim();
        return trim.split(" ")[0];
    }

    //flow
    public String parserFlow(String line){
        String trim = line.substring(line.lastIndexOf("\"") + 1).trim();
        return trim.split(" ")[1];
    }

    //Organize format
    //function
    public String[] parser(String line){

        String ip = "Ip:" + parserIp(line);

        String time = "Time:" + parserTime(line);

        String url = "url:" + parserUrl(line);

        String status = "Status:" + parserStatus(line);

        String flow = "Flow:" + parserFlow(line);

        String[] lines = {ip,time,url,status,flow};
        return lines;
    }
}

