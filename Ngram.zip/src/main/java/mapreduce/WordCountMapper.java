package mapreduce;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;
import java.util.Scanner;

public class WordCountMapper extends Mapper<LongWritable, Text, Text, LongWritable> {
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        // First get a row of data
        String lines = value.toString();
        //Doing ngram split
        Ngram ngram = new Ngram();
        Scanner input=new Scanner(System.in);
        System.out.print("Please input N:");
        int n=input.nextInt();
        lines = ngram.RemovePunctuation(lines);
        String[] result = ngram.n_gram(lines,n);
        //map
        for (String str : result) {
            context.write(new Text(str), new LongWritable(1));
        }
    }
}