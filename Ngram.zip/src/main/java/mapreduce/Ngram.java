package mapreduce;

import java.util.Scanner;

public class Ngram {
    //Remove Punctuation
    public String RemovePunctuation(String str){
        str = str.replaceAll("[\\n`~!@#$%^&*()+=|{}':;',\\\\[\\\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？]" , "");
        return str;
    }
    //doing ngram
    public String[] n_gram(String str,int n){
        String[] words = str.split(" ");
        //n cant larger than string length
        if(n>words.length){
            n = words.length;
            System.out.println("N is invalid, the length of words is "+n);
        }
        //Reorganize data into ngram form
        String[] ngramwords = new String[words.length-n+1];
        for(int i=0; i<=words.length-n; i++){
            for(int j=0; j<n; j++){
                if(j==0){
                    ngramwords[i] = words[i];
                }
                else {
                    ngramwords[i] +=  " " + words[i+j] ;
                }
            }
        }
        return ngramwords;
    }

}
